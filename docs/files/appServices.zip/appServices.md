# Available Services

## 1. Keycloak:

A unified system for storing user data with basic information. This system is used in:

- the web version of the application  
- services – retrieving user information from a single source  
- mobile applications  
- VR applications  
- SSO (Single Sign-On) – a single entry point  

> URL: https://0/  
> Login: user  
> Password: 00000  
> Fake Mail: http://0.0.0.0:0000  
{.is-info}

> Local mail for testing:  
> URL: http://0.0.0.0:0000  
{.is-info}

### Logging into the platform and user information

<font size="4" color='Blue'>**http://00000.online/login**</font>

| Email             | Password  | Role    |
| ----------------- | --------- | ------- |
| admin@test        | 00000000  | admin   |
| student@test      | 00000000  | student |
| expert@expert.com | 00000000  | expert  |

## 2. RabbitMQ:

> URL: http://00000.online:00000  
> Login: user  
> Password: 00000  
{.is-info}
	
## 4. Server Methods Documentation:

- 00000

## 5. Web portal: `http://<branch-name>00000.online`

where: `<branch-name>` is the name of the branch being pushed to the Git repository

Stand update principle: Any code that is pushed to a branch is automatically deployed to the servers and is accessible via the address bar:

- dev: http://000000.online  
- main: http://000000.online  

## 6. Web Story: `http://<branch-name>.0000000.online`

where: `<branch-name>` is the name of the branch being pushed to the Git repository

This page is intended for development only and shows the components that developers are creating.

**Main features:**

- Check component functionality  
- List of available components  
- Maintaining component documentation (in progress)  
- PlayGround – a place where you can assemble a block prototype and play with the platform’s builder capabilities  

> The functionality is in experimental mode  
{.is-info}

Stand update principle: Any code that is pushed to a branch is automatically deployed to the servers and is accessible via the address bar:

- dev: http://000000.online  
- main: http://000000.online  

# Application Workflow Diagram

```diagram```

# How to run the project

## 1. Install PostgreSQL

```
docker run -d -p 0000:0000 --name 00000 \
  -e POSTGRES_PASSWORD=00000 \
  -e POSTGRES_USER=00000 \
  -e POSTGRES_DB=postgres postgres
```

## 2. Install RabbitMQ

```
docker run -d --name rabbit-mq \
  -p 0000:0000 -p 00000:00000 \
  -e RABBITMQ_DEFAULT_USER=00000 \
  -e RABBITMQ_DEFAULT_PASS=00000 \
  rabbitmq:3-management
```

## 3. To run the BackEnd project, you need to download the following repositories:

- https://github.com/00000 – a user management middleware  
- https://github.com/00000 – a service for storing data about courses and their progress  
- https://github.com/00000 – a payment service  
- https://github.com/00000 – a builder (constructor) service  

## 4. Install Keycloak

To install, you can use the `docker-compose.yaml` file in the `keycloak` folder of the `00000` repository:

- go to the repository `00000`  
- go to the `keycloak` folder  
- run `00000` to start the containers. The startup takes a couple of minutes.

**Initialization:**

```
POSTGRES_SERVER=00000
POSTGRES_USER=00000
POSTGRES_PASSWORD=00000

KEY_CLOAK_SERVER_URL=http://00000/auth
KEY_CLOAK_CLIENT_ID=00000-client
KEY_CLOAK_CLIENT_SECRET=<take from Keycloak>
KEY_CLOAK_ADMIN_CLIENT_SECRET=<take from Keycloak>
KEY_CLOAK_REALM=00000
KEY_CLOAK_CALLBACK_URI=http://00000/callback
```

**For `qbe-lms`**

```
POSTGRES_SERVER=00000
POSTGRES_USER=00000
POSTGRES_PASSWORD=00000
KEY_CLOAK_CLIENT_SECRET=<take from Keycloak>
KEY_CLOAK_ADMIN_CLIENT_SECRET=<take from Keycloak>

SPACES_KEY=00000
SPACES_SECRET=00000

AMQP_URI=amqp://00000/
```

P.S. `SPACES_KEY` and `SPACES_SECRET` are taken from DigitalOcean Spaces. These keys were created exclusively for the Dev environment.

**For `qbe-construct`**

```
PUBLIC_URL=<URL for redirect after payment>

# DB
POSTGRES_SERVER=00000
POSTGRES_USER=00000
POSTGRES_PASSWORD=00000

# Stripe
STRIPE_API_KEY=<request if access is needed>
STRIPE_ENDPOINT_SECRET=<request if access is needed>

# Keycloak
KEY_CLOAK_CLIENT_SECRET=<take from Keycloak>
KEY_CLOAK_ADMIN_CLIENT_SECRET=<take from Keycloak>

# ApiLayer
API_LAYER_KEY=<request if access is needed>

# CloudPayments
CLOUD_PAYMENTS_SECRET_KEY=<request if access is needed>

# Prodamus
PRODAMUS_SUBDOMAIN_NAME=00000
PRODAMUS_SECRET_KEY=<request if access is needed>
```

**For `qbe-builder`**

```
POSTGRES_SERVER=00000
POSTGRES_USER=00000
POSTGRES_PASSWORD=00000

KEY_CLOAK_CLIENT_SECRET=<take from Keycloak>
KEY_CLOAK_ADMIN_CLIENT_SECRET=<take from Keycloak>

ENVS={"CLOUD_PAYMENTS_KZ_PUBLIC_ID": "<request if needed>", "CLOUD_PAYMENTS_RUS_PUBLIC_ID": "<request if needed>"}
```

## 6. Start 4 BackEnd servers

- go to the `qbe-auth` directory and start: `pnpm dev`  
- go to the `qbe-lms` directory and start: `pnpm dev`  
- go to the `qbe-builder` directory and start: `pnpm dev`  
- go to the `qbe-payments` directory and start: `pnpm dev`  

## 7. To run the FrontEnd project

**You need to download the following repositories:**

- https://github.com/00000 – the main user interface repository  
- https://github.com/00000 – instructions for running the server via Docker-compose and instructions for all pages  

**Notes:**  
- `pnpm` is used for dependency management, so you need to have it installed if not already.  
- We use our custom page builder, so all page snapshots are stored in a separate `server` repository.  

**Development Initialization (using local servers):**  

1. Go to the `packages/web` folder  
2. Create a file `.env.local` with the following content:

```
CONF_AUTH_HOST=http://00000
CONF_BUILDER_HOST=http://00000
CONF_LMS_HOST=http://00000
CONF_PAYMENT_HOST=http://00000
```

### **Running the project:**

- go to the `packages/web` directory  
- start the project in development mode: `pnpm dev`  

### If you chose to use the local server, the application will be empty and you need to load pages:

On the first run, you need to create all applications via a CURL request (or via the CLI). It is recommended to use the `OpenAPI` interface:

- open the page http://00000  
- click **Authorize**  
- enter login/password: `00000` / `00000`  
- go to **Create Application** and click **Try it out**  
- sequentially send the following JSON:

**Builder:**

```json
{
  "name": "Builder",
  "path": "builder",
  "description": "We are using this application to create or edit other pages"
}
```

**Root application:**

```json
{
  "name": "Root",
  "path": "root",
  "description": "Root application"
}
```

## 8. Running the application

After initialization, the application becomes available at: 00000

# Production Deployment

To use the infrastructure in production mode, do the following:

1. download the repository https://github.com/00000  
2. create databases for each BackEnd server  
3. add the extension to the databases:  
   ```sql
   CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
   ```  
4. go to the `docker` folder  
5. copy `.env.example` to `.env` and `.env.rabbitmq.example` to `.env.rabbitmq`  
6. open the copied files and fill in the required fields  
7. run `docker-compose up -d`  
8. configure Keycloak  

# Why We Need a Builder

## Initial goal:

- ability to construct course pages based on the GetCourse principle  
- building business processes  
- an element constructor for VR  

## Main advantages of the builder in this solution:

- splitting code into small components to simplify development  
- the ability to build an unlimited number of applications  
- each component package can be developed by an independent team  
- partial project assembly is possible  
- we can assemble course pages based on the GetCourse principle  
- designing business processes without writing code and with the ability to build them in the interface  
- using the builder to construct dynamic spaces for VR  

## Disadvantages

- component design must occur during the planning stage  
- interaction between components is built on a single concept:  
  - handlers – trigger processing  
  - stores – interaction with other components  
  - page – isolation of components within a page  
  - globalValues – the single store principle  
- constructing all pages through the builder  