# SFC Backend API

## Base URL

- `http://<host>/api/v1`

## Auth Model

- The API uses Bearer token authorization via Laravel Sanctum.
- On login, a pair of tokens is returned:
  - `access_token` (short-lived, for regular API requests)
  - `refresh_token` (long-lived, used only for refreshing tokens)
- TTL is configurable via environment variables:
  - `API_ACCESS_TOKEN_TTL_MINUTES` (default `60`)
  - `API_REFRESH_TOKEN_TTL_DAYS` (default `30`)
- For protected routes:
  - `Authorization: Bearer <access_token>`
- To refresh tokens, use `POST /refresh` with the `refresh_token` in the `Authorization` header.
- Recommended headers:
  - `Accept: application/json`
  - `Content-Type: application/json` (for JSON requests)

### Frontend Login Note

- In the `sfc-frontend`, a single login form is used, with a single endpoint `POST /api/v1/login`.
- The user's role is determined on the backend, and then the frontend uses the appropriate scope (`admin` or `user`) for further requests.

## Public Asset Endpoints

Prefix: `/api/v1`

- `GET /venue-images/{venueImage}` — return the venue image file.
- `GET /users/{user}/avatar` — return the user's avatar.

## Auth Entry Point

Prefix: `/api/v1`

- `POST /login` — a single entry point for administrators and participants.
  - body: `{ "phone": "+79990001122", "password": "secret" }`
  - the response returns a `scope` (`admin` or `user`) and a pair of tokens.

## Admin API

Prefix: `/api/v1/admin`

### Auth

- `POST /refresh` — refresh the token pair (use the refresh token).
- `POST /logout` — end the current session.
- `POST /logout-all` — end all user sessions.
- `GET /me` — get the current user.

### Game Days

- `GET /game-days` — get a list of game days with pagination and filters.
  - query: `status`, `location_type`, `date_from`, `date_to`, `page`
- `GET /game-days/metadata` — get reference data for the game day form (statuses, location types, venues).
- `GET /game-days/{gameDay}` — get a detailed game day record (with lineups, statistics, games, teams).
- `POST /game-days` — create a new game day.
- `PUT/PATCH /game-days/{gameDay}` — update game day parameters.
- `DELETE /game-days/{gameDay}` — delete the game day.
- `POST /game-days/{gameDay}/close-registration` — close registration for the game day.
- `POST /game-days/{gameDay}/open-registration` — open registration for the game day.
- `POST /game-days/{gameDay}/complete` — mark the game day as completed.
- `POST /game-days/{gameDay}/register-user` — register a user for a game day on behalf of an administrator.
- `PATCH /game-days/{gameDay}/participants/{user}/team` — assign a participant to a team within the game day.
- `POST /game-days/{gameDay}/calculate-results` — recalculate tournament results and statistics.
- `POST /game-days/{gameDay}/games` — add a game to the game day's schedule.
- `PATCH /game-days/{gameDay}/games/{game}` — update a specific game's parameters.
- `DELETE /game-days/{gameDay}/games/{game}` — delete a game from the game day.

#### `POST /game-days/{gameDay}/register-user` body example

```json
{
  "user_id": 25,
  "pluses_count": 2
}
```
`pluses_count` is optional (default `0`), allowed range: `0..20`.

#### `PATCH /game-days/{gameDay}/participants/{user}/team` body example

```json
{
  "team_id": 1
}
```

Restriction: `POST /game-days/{gameDay}/games` is only available if registration for the game day is closed (`registration_closed_at != null`), otherwise it returns `422`.

Format for `start_time` on create/update: `HH:mm` (recommended) or `HH:mm:ss`. The server normalizes and stores the value as `HH:mm`.

#### `POST /game-days` body example

```json
{
  "date": "2026-03-20",
  "start_time": "19:00",
  "location_type": "indoor",
  "venue_id": 1,
  "max_players": 20,
  "cost": 500,
  "status": "planned"
}
```

### Game Day Templates

- `GET /game-day-templates` — get a list of game day templates.
  - query: `page`
- `POST /game-day-templates` — create a game day template for reuse.
- `PUT/PATCH /game-day-templates/{id}` — update a game day template.
- `DELETE /game-day-templates/{id}` — delete a game day template.

Format for `start_time` on create/update: `HH:mm` (recommended) or `HH:mm:ss`. The server normalizes and stores the value as `HH:mm`.

#### `POST /game-day-templates` body example

```json
{
  "name": "Evening Hall",
  "start_time": "19:00",
  "location_type": "indoor",
  "venue_id": 1,
  "max_players": 20,
  "cost": 500
}
```

### Venues

- `GET /venues` — get a list of venues.
- `GET /venues/{id}` — get detailed information about a venue.
- `POST /venues` — create a new venue.
- `PUT/PATCH /venues/{id}` — update venue data.
- `DELETE /venues/{id}` — delete a venue.
- `POST /venues/{venue}/images` — upload multiple photos (`multipart/form-data`, field `images[]`, optional `primary_index`).
- `PATCH /venues/{venue}/images/sort` — update the photo display order.
  - body: `{ "image_ids": [3, 8, 11] }`
- `PATCH /venues/{venue}/images/{image}/primary` — make the selected photo primary.
- `DELETE /venues/{venue}/images/{image}` — delete a venue photo.

### Teams

- `GET /teams` — get a list of teams.
- `POST /teams` — create a team.
- `PATCH /teams/{team}` — update a team's name.
- `DELETE /teams/{team}` — delete a team (if it is not used in games/assignments).

#### `POST /teams` / `PATCH /teams/{team}` body example

```json
{
  "name": "Red"
}
```

### Registrations

- `GET /registrations` — get a list of game day registrations.
  - query: `game_day_id`, `status`, `paid` (`1|0|paid|unpaid`), `page`
- `PATCH /registrations/{registration}/payment` — change the registration's payment status.
  - body: `{ "paid": "on" }` (mark as paid)
  - body: `{}` (unmark payment)
- `PATCH /registrations/{registration}/pluses` — change the number of pluses in the registration.
  - body: `{ "pluses_count": 3 }` (`0..20`)
- `DELETE /registrations/{registration}` — delete a user's registration from the game day.

### User Activity Logs

- `GET /user-activity-logs` — get the log of actions by users and administrators.
  - query: `q`, `action`, `target_user_id`, `page`
  - actions:
    - `user_registered`
    - `user_cancelled`
    - `admin_registered_user`
    - `admin_removed_registration`
    - `admin_updated_payment_status`
    - `user_updated_pluses_count`
    - `admin_updated_pluses_count`

### Users

- `GET /users` — get a list of users.
  - query: `q`, `role` (`admin|participant`), `state` (`active|deleted|all`), `page`
- `GET /users/{user}` — get the user's record with registrations and teams.
- `POST /users` — create a user and return a temporary password.
- `POST /users/{user}/avatar` (`multipart/form-data`, field `avatar`) — upload/replace the user's avatar.
- `DELETE /users/{user}/avatar` — delete the user's avatar.
- `POST /users/{user}/restore` — restore a previously deleted user.
- `POST /users/{user}/reset-password` — reset the user's password and issue a new temporary password.
- `PATCH /users/{user}/note` — update an internal note for the user.
- `GET /users/debtors` — get a list of debtors (users with unpaid registrations).
  - query: `q`, `page`
- `DELETE /users/{user}` — soft delete the user.

#### `POST /users` body example

```json
{
  "username": "Ivan Ivanov",
  "phone": "+79990001122",
  "email": "ivan@example.com",
  "role": "participant",
  "note": "Don't forget to follow up on payment for past games"
}
```

#### `PATCH /users/{user}/note` body example

```json
{
  "note": "Will pay the debt on Friday"
}
```
`note` can be `null` to clear it.

### Profile

- `GET /profile` — get the current administrator’s profile.
- `PATCH /profile` — update the current administrator’s profile.
- `POST /profile/avatar` (`multipart/form-data`, field `avatar`) — upload/replace the current administrator’s avatar.
- `DELETE /profile/avatar` — delete the current administrator’s avatar.

#### `PATCH /profile` body example

```json
{
  "username": "Ivan Ivanov",
  "phone": "+79990001122",
  "email": "ivan@example.com",
  "password": "new-secret"
}
```

### Dictionaries

Prefix: `/api/v1/admin/dictionaries`

- `GET /venue-types` — get a list of venue types.
- `GET /game-day-statuses` — get a list of game day statuses.
- `GET /registration-statuses` — get a list of registration statuses.
- `GET /payment-statuses` — get a list of payment statuses.

Response format:

```json
{
  "items": [
    { "name": "indoor", "label": "Hall" },
    { "name": "outdoor", "label": "Outdoor" }
  ]
}
```

## User API

Prefix: `/api/v1/user`

### Auth

- `POST /refresh` — refresh the token pair (use the refresh token).
- `POST /logout` — end the current user session.
- `POST /logout-all` — end all user sessions.
- `GET /me` — get the profile of the current participant.

### Game Days

- `GET /game-days` — get a list of game days available to the participant.
  - query: `status` (`planned`, `completed`), `page`
  - default: `status=planned`
- `GET /game-days/{gameDay}` — get detailed information about the game day and the participant's position in the queue.
- `POST /game-days/{gameDay}/register` — register for the game day.
- `PATCH /game-days/{gameDay}/pluses` — change your pluses count in the game day registration.
- `POST /game-days/{gameDay}/cancel` — cancel your registration for the game day.

#### `POST /game-days/{gameDay}/register` body example

```json
{
  "pluses_count": 1
}
```
`pluses_count` is optional (default `0`), allowed range: `0..20`.

### Debtors

- `GET /debtors` — get a list of debtors available to the participant.
  - query: `q`, `page`

### Profile

- `GET /profile` — get the profile of the current participant.
- `PATCH /profile` — update the profile of the current participant.
- `POST /profile/avatar` (`multipart/form-data`, field `avatar`) — upload/replace the current participant’s avatar.
- `DELETE /profile/avatar` — delete the current participant’s avatar.

### Dictionaries

Prefix: `/api/v1/user/dictionaries`

- `GET /game-day-statuses` — get a list of game day statuses.
- `GET /registration-statuses` — get a list of registration statuses.
- `GET /payment-statuses` — get a list of payment statuses.

## Response Format

- Success: JSON object with `message`, `item`, `items`, `pagination`, `options` (depending on the endpoint).
- Errors:
  - `401` — unauthorized
  - `403` — forbidden
  - `404` — not found
  - `422` — validation or business error

## Refresh Strategy

- A refresh token rotation strategy is used:
  - on `POST /refresh`, the current refresh token is invalidated
  - at the same time, the associated access token of the current session is invalidated
  - a new access/refresh token pair is issued
- The refresh token cannot be used for regular business endpoints.